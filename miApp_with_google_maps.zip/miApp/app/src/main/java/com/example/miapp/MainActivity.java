package com.example.miapp;

import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.PreparedStatement;
import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import static android.os.StrictMode.*;
import static android.widget.Toast.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileNotFoundException;



public class MainActivity extends AppCompatActivity {


    String correo; //USER CORREO APPP
    String contrasena;  //PASS CORREO APP
    EditText correoEnvio; //CORREO FORMULARIO
    Button enviar;
    Button validar;
    Session session;


    //ARCHIVO

    String archivo="miarchivo.txt"; //ARCHIVO CREADO POR DEFECTO


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        enviar = (Button) findViewById(R.id.btnValidar);
        validar= (Button) findViewById(R.id.btnCodigo);
        correoEnvio = (EditText) findViewById(R.id.correoCliente);
        correo = "ubernavideno@gmail.com";
        contrasena = "swgrupo5";

        enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                makeText(MainActivity.this,"Versión 1.0.", LENGTH_SHORT).show();

                ThreadPolicy policy = new ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
                Properties properties = new Properties();
                properties.put("mail.smtp.host", "smtp.googlemail.com");
                properties.put("mail.smtp.socketFactory.port", "465"); //Socket para recibir respuesta
                properties.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
                properties.put("mail.smtp.auth", "true");
                properties.put("mail.smtp.port", "465"); //puerto de gmail

                try {
                    session = javax.mail.Session.getDefaultInstance(properties, new Authenticator() {
                        @Override
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(correo, contrasena);

                        }

                    });

                    if (session != null) {
                        makeText(MainActivity.this,"Estoy en la sesion", LENGTH_SHORT).show();
                        Message message = new MimeMessage(session);
                        try {
                            message.setFrom(new InternetAddress(correo));
                            makeText(MainActivity.this,"Creando mensaje", LENGTH_SHORT).show();
                            message.setSubject("Confirmación de correo electrónico");
                            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(correoEnvio.getText().toString()));
                            String numReal=crearAleatorio();
                            message.setContent("Se ha registrado este correo en la <b>Aplicación uber navideño<b> <br><br>"+
                                    "Favor ingresar el siguiente código para confirmar <br>" +
                                    numReal+"<br><br> Este mensaje se generó automáticamente. No responda a este correo", "text/html;charset=utf-8");
                            Transport.send(message);
                            FileOutputStream outputStream=null;
                            outputStream = openFileOutput(archivo, MODE_PRIVATE);
                            outputStream.write(numReal.getBytes());
                            outputStream.close();
                            makeText(MainActivity.this,"Enviando mensaje", LENGTH_SHORT).show();


                        } catch (MessagingException e) {
                            e.printStackTrace();
                            makeText(MainActivity.this,"tuve error al enviar memsaje ", LENGTH_SHORT).show();
                        }


                    }


                } catch (Exception a) {
                    a.printStackTrace();

                }
            }
        });


        validar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    FileInputStream inputStream= getApplicationContext().openFileInput(archivo);
                    InputStreamReader streamReader=new InputStreamReader(inputStream, "utf-8");
                    BufferedReader reader=new BufferedReader(streamReader);
                    String line="";
                    line=reader.readLine();
                    EditText codigo=(EditText) findViewById(R.id.codigoValidacion);
                    codigo.getText().toString();


                    if(codigo.getText().toString().equals(line)){
                        makeText(MainActivity.this,"Correo validado", LENGTH_SHORT).show();
                        correoEnvio=(EditText) findViewById(R.id.correoCliente);
                        correoEnvio.setBackgroundColor(Color.GREEN);
                        correoEnvio.setEnabled(false);
                        codigo.setEnabled(false);
                    }else{
                        makeText(MainActivity.this,"Los códigos no coinciden", LENGTH_SHORT).show();
                        correoEnvio.setBackgroundColor(Color.RED);
                        correoEnvio.setText("");

                    }

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }catch(UnsupportedEncodingException a){

                }catch(IOException r){

                }


            }
        });
    }

    public String crearAleatorio(){
        int N=0;
        int M=1000000;
        int valorAleatorio;
        valorAleatorio= (int) (Math.random()*(N-M+1)+M);
        return String.valueOf(valorAleatorio);
    }

    public Connection conexionBD(){
        Connection conexion= null;

        try{
            Class.forName("net.sourceforge.jtds.jdbc.Driver").newInstance();
            conexion= DriverManager.getConnection("jdbc:jtds:sqlsever://192.168.1.17:databaseName= DB_A54790_ubernavideno;user=DB_A54790_ubernavideno_admin;pass=gr5sw2020;");

        }catch(Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage(), LENGTH_LONG).show();
            e.printStackTrace();
        }

        return conexion;


    }

    public void selectTables(){
        try{
            PreparedStatement result=conexionBD().prepareStatement("SELECT CAST(table_name as varchar)  FROM INFORMATION_SCHEMA.TABLES");
            result.executeUpdate();
            Toast.makeText(getApplicationContext(),"Búsqueda exitosa", LENGTH_LONG).show();
        }catch(Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage(), LENGTH_LONG).show();

        }
    }
}


