package com.example.miapp.Validacion;

import android.content.Context;
import android.os.StrictMode;
import com.example.miapp.MainActivity;
import com.example.miapp.R;
import java.io.FileOutputStream;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import static android.widget.Toast.LENGTH_SHORT;
import static android.widget.Toast.makeText;

import java.util.regex.Pattern;
import android.util.Patterns;
import static android.os.StrictMode.*;
import static android.widget.Toast.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

public class ValidarCorreo {

    String correo;

    public int enviarCorreoValidacion(String correo){

        Session session;
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Properties properties = new Properties();
        properties.put("mail.smtp.host", "smtp.googlemail.com");
        properties.put("mail.smtp.socketFactory.port", "465"); //Socket para recibir respuesta
        properties.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.port", "465"); //puerto de gmail

        try {
            session = javax.mail.Session.getDefaultInstance(properties, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication("ubernavideno@gmail.com", "swgrupo5");

                }

            });

            if (session != null) {

                Message message = new MimeMessage(session);
                try {
                    message.setFrom(new InternetAddress(correo));
                    message.setSubject("Confirmación de correo electrónico");
                    message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(correo));
                    String numReal=crearAleatorio();
                    message.setContent("Se ha registrado este correo en la <b>Aplicación uber navideño<b> <br><br>"+
                            "Favor ingresar el siguiente código para confirmar <br>" +
                            numReal+"<br><br> Este mensaje se generó automáticamente. No responda a este correo", "text/html;charset=utf-8");
                    Transport.send(message);
                    FileOutputStream outputStream=null;
                    //outputStream = openFileOutput("archivo.txt", Context.MODE_PRIVATE);
                    outputStream.write(numReal.getBytes());
                    outputStream.close();
                                       //selectTables();


                } catch (MessagingException e) {
                    e.printStackTrace();

                }


            }


        } catch (Exception a) {
            a.printStackTrace();

        }

        return 0;


    }


    public boolean correoValido(String correo){
        Pattern pattern = Patterns.EMAIL_ADDRESS;
        return pattern.matcher(correo).matches();
    }

    public String crearAleatorio(){
        int N=0;
        int M=1000000;
        int valorAleatorio;
        valorAleatorio= (int) (Math.random()*(N-M+1)+M);
        return String.valueOf(valorAleatorio);
    }


}
