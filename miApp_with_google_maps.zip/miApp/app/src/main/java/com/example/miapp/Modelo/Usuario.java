package com.example.miapp.Modelo;

public class Usuario {
    String user,correo, password;

    public Usuario(){

    }

    public String getCorreo() {
        return correo;
    }

    public void setUser(String user){
        this.user=user;
    }

    public void setCorreo(String correo){
        this.correo=correo;
    }

    public void setPassword(String password){
        this.password=password;
    }
}
